import React, { useState } from 'react';
import { generateArtIdea } from '../services/geminiService';
import { ArtIdea } from '../types';

const ArtGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [idea, setIdea] = useState<ArtIdea | null>(null);
  const [error, setError] = useState<string | null>(null);

  const getErrorMessage = (err: any) => {
    const msg = err?.message || "";
    if (!process.env.API_KEY) {
      return "Concept engine offline: No API Key detected in build configuration.";
    }
    if (msg.includes("401") || msg.includes("403")) {
      return "Access denied: The AI provider rejected the credentials. Check your deployment environment.";
    }
    if (msg.includes("429") || msg.includes("quota")) {
      return "Generator busy: Rate limit reached. Please wait a minute before requesting a new spark.";
    }
    return "The creative spark flickered out. Please check your network and try again.";
  };

  const quickPrompts = [
    "Cyberpunk Renaissance",
    "Solitude in a library",
    "Dreams of a clockmaker",
    "Whispers in a storm"
  ];

  const handleGenerate = async (e: React.FormEvent | string) => {
    if (typeof e !== 'string') e.preventDefault();
    const targetPrompt = typeof e === 'string' ? e : prompt;
    
    if (!targetPrompt.trim() || loading) return;
    
    setPrompt(targetPrompt);
    setLoading(true);
    setIdea(null);
    setError(null);
    try {
      const result = await generateArtIdea(targetPrompt);
      setIdea(result);
    } catch (err: any) {
      console.error("Generator failed:", err);
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-16 py-8">
      <div className="text-center max-w-3xl mx-auto space-y-6">
        <h2 className="text-5xl font-bold">Spark Your Next Masterpiece</h2>
        <p className="text-xl text-slate-500 font-light leading-relaxed">
          Stuck in a creative block? Describe a mood, a dream fragment, or a keyword, and we'll design a full artistic concept for you.
        </p>
      </div>

      <div className="max-w-2xl mx-auto space-y-8">
        <form onSubmit={handleGenerate} className="relative group">
          <input 
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe a theme, vibe or material..."
            className="w-full bg-white border-2 border-stone-100 rounded-3xl pl-8 pr-40 py-6 text-xl focus:ring-4 focus:ring-indigo-100 focus:border-indigo-400 transition-all outline-none shadow-xl"
          />
          <button 
            type="submit"
            disabled={loading}
            className="absolute right-3 top-3 bottom-3 bg-slate-900 text-white px-8 rounded-2xl font-bold hover:bg-indigo-600 transition-all shadow-lg active:scale-95 disabled:opacity-50 flex items-center gap-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                Spark
              </>
            )}
          </button>
        </form>

        {error && (
          <div className="p-5 bg-red-50 text-red-900 rounded-2xl border border-red-100 text-sm flex items-start gap-4 animate-in slide-in-from-top-4">
            <svg className="w-5 h-5 text-red-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <p>{error}</p>
          </div>
        )}

        <div className="flex flex-wrap justify-center gap-3">
          <span className="text-sm font-bold text-slate-400 uppercase tracking-widest w-full text-center mb-2">Try these themes</span>
          {quickPrompts.map((p, i) => (
            <button 
              key={i}
              onClick={() => handleGenerate(p)}
              className="px-4 py-2 bg-white hover:bg-indigo-50 border border-stone-200 rounded-full text-sm font-medium text-slate-600 transition-all hover:border-indigo-200"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {idea && (
        <div className="max-w-5xl mx-auto bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-stone-100 flex flex-col md:flex-row animate-in zoom-in-95 fade-in duration-700">
          <div className="md:w-2/5 bg-indigo-600 text-white p-12 flex flex-col justify-between relative overflow-hidden">
             <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl"></div>
             <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-400/20 rounded-full -ml-24 -mb-24 blur-2xl"></div>
             
             <div className="space-y-4 relative z-10">
               <h4 className="text-xs font-bold uppercase tracking-[0.3em] text-indigo-200">The Vibe</h4>
               <p className="text-4xl md:text-5xl font-serif italic font-bold leading-tight">{idea.vibe}</p>
             </div>

             <div className="mt-12 space-y-6 relative z-10">
                <div className="h-px w-12 bg-indigo-400"></div>
                <p className="text-indigo-100 text-lg leading-relaxed font-light italic">
                  "Art is the stored honey of the human soul."
                </p>
             </div>
          </div>
          <div className="md:w-3/5 p-12 lg:p-16 space-y-10">
            <div className="space-y-4">
              <h3 className="text-4xl font-bold text-slate-900 tracking-tight">{idea.title}</h3>
              <p className="text-slate-600 text-xl leading-relaxed font-light">
                {idea.concept}
              </p>
            </div>
            
            <div className="space-y-6">
              <h4 className="font-bold text-slate-900 uppercase tracking-[0.1em] text-sm flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                Essential Toolkit
              </h4>
              <div className="grid grid-cols-2 gap-3">
                {idea.materials.map((m, i) => (
                  <div key={i} className="flex items-center gap-3 bg-stone-50 px-5 py-4 rounded-2xl border border-stone-100 hover:border-indigo-200 transition-colors">
                    <svg className="w-4 h-4 text-indigo-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg>
                    <span className="text-slate-800 font-semibold text-sm">{m}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ArtGenerator;