import React, { useState, useRef, useEffect } from 'react';
import { chatWithArtHistorian } from '../services/geminiService';
import { ChatMessage } from '../types';

const ArtHistorian: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Greetings, seeker of beauty. I am your guide through the annals of human creativity. Which artistic movement, creator, or masterpiece shall we explore today?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const getErrorMessage = (err: any) => {
    const msg = err?.message || "";
    if (!process.env.API_KEY) {
      return "The connection to the archives failed: Missing API Key in deployment environment.";
    }
    if (msg.includes("401") || msg.includes("403") || msg.includes("API key")) {
      return "Authentication failed: The AI provider rejected the API key. Verify its validity in your dashboard.";
    }
    if (msg.includes("429") || msg.includes("quota")) {
      return "I'm currently overwhelmed by other patrons (Rate limit reached). Please try again in 60 seconds.";
    }
    return "The conversation was severed by a network anomaly. Please check your internet connection.";
  };

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setLoading(true);
    setError(null);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      
      const response = await chatWithArtHistorian(userMessage, history);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (err: any) {
      console.error("Chat failed:", err);
      const friendlyError = getErrorMessage(err);
      setError(friendlyError);
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: `Forgive me, but I've encountered a technical difficulty: ${friendlyError}` 
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[75vh] flex flex-col bg-white rounded-3xl shadow-2xl overflow-hidden border border-stone-200">
      <div className="bg-slate-900 text-white p-6 flex items-center justify-between shadow-lg z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center ring-2 ring-indigo-400">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
          </div>
          <div>
            <h3 className="font-bold text-lg">Curator AI</h3>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Art History & Criticism</p>
          </div>
        </div>
        {error && (
          <div className="hidden md:flex items-center gap-2 bg-red-500/20 text-red-200 px-4 py-1.5 rounded-full text-xs font-semibold animate-pulse border border-red-500/30">
            <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
            AI Offline
          </div>
        )}
      </div>

      <div className="flex-grow overflow-y-auto p-6 space-y-6 bg-stone-50">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
            <div className={`max-w-[85%] rounded-2xl p-5 shadow-sm ${
              m.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none' 
                : 'bg-white text-slate-800 rounded-tl-none border border-stone-200'
            }`}>
              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white text-slate-400 rounded-2xl p-4 shadow-sm rounded-tl-none border border-stone-200 flex gap-2">
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce"></span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="p-4 bg-white border-t border-stone-200">
        {error && (
          <div className="mb-4 px-4 py-3 bg-red-50 text-red-800 text-sm rounded-xl border border-red-100 flex items-start justify-between shadow-sm">
            <span className="flex-1 pr-4">{error}</span>
            <button onClick={() => setError(null)} className="font-bold text-red-600 hover:text-red-800 transition-colors">Dismiss</button>
          </div>
        )}
        <form onSubmit={handleSend} className="relative flex items-center">
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about Baroque, Picasso, or the secret of the Mona Lisa..."
            className="w-full bg-stone-100 border-none rounded-2xl py-4 pl-6 pr-14 focus:ring-2 focus:ring-indigo-500 transition-all outline-none"
            disabled={loading}
          />
          <button 
            type="submit"
            disabled={loading}
            className="absolute right-2 p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors shadow-md disabled:opacity-50"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14M12 5l7 7-7 7"></path></svg>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ArtHistorian;