
import React from 'react';
import { AppTab } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200 px-6 py-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">A</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-800">ArtVision<span className="text-indigo-600 font-light">AI</span></h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <button 
              onClick={() => setActiveTab(AppTab.ANALYZER)}
              className={`text-sm font-medium transition-colors ${activeTab === AppTab.ANALYZER ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Art Analyzer
            </button>
            <button 
              onClick={() => setActiveTab(AppTab.EXPLORER)}
              className={`text-sm font-medium transition-colors ${activeTab === AppTab.EXPLORER ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Art Historian
            </button>
            <button 
              onClick={() => setActiveTab(AppTab.GENERATE)}
              className={`text-sm font-medium transition-colors ${activeTab === AppTab.GENERATE ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-800'}`}
            >
              Creative Sparks
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-grow max-w-6xl mx-auto w-full px-6 py-12">
        {children}
      </main>

      {/* Mobile Nav */}
      <footer className="md:hidden sticky bottom-0 z-50 bg-white border-t border-stone-200 px-6 py-3">
        <div className="flex justify-around">
          <button onClick={() => setActiveTab(AppTab.ANALYZER)} className={`flex flex-col items-center gap-1 ${activeTab === AppTab.ANALYZER ? 'text-indigo-600' : 'text-slate-400'}`}>
            <span className="text-[10px] font-bold uppercase tracking-wider">Analyze</span>
          </button>
          <button onClick={() => setActiveTab(AppTab.EXPLORER)} className={`flex flex-col items-center gap-1 ${activeTab === AppTab.EXPLORER ? 'text-indigo-600' : 'text-slate-400'}`}>
            <span className="text-[10px] font-bold uppercase tracking-wider">Explore</span>
          </button>
          <button onClick={() => setActiveTab(AppTab.GENERATE)} className={`flex flex-col items-center gap-1 ${activeTab === AppTab.GENERATE ? 'text-indigo-600' : 'text-slate-400'}`}>
            <span className="text-[10px] font-bold uppercase tracking-wider">Spark</span>
          </button>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
