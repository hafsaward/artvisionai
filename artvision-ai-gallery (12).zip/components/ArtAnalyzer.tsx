import React, { useState, useRef } from 'react';
import { analyzeArtImage } from '../services/geminiService';
import { ArtAnalysis } from '../types';

const ArtAnalyzer: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ArtAnalysis | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getErrorMessage = (err: any) => {
    const msg = err?.message || "";
    
    if (msg.includes("401") || msg.includes("403") || msg.includes("API key")) {
      return "The AI service rejected the request. Please check if your API key is correctly configured.";
    }
    
    if (msg.includes("429") || msg.includes("quota")) {
      return "Rate limit exceeded. Please wait a moment before trying again.";
    }

    if (msg.includes("fetch") || msg.includes("NetworkError") || msg.includes("Failed to fetch")) {
      return "Network error: Unable to connect to the AI archives. Please check your internet connection.";
    }
    
    return msg || "Analysis failed: An unexpected error occurred while processing the masterpiece.";
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        setImage(reader.result as string);
        performAnalysis(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const performAnalysis = async (base64: string) => {
    setLoading(true);
    setAnalysis(null);
    setError(null);
    try {
      const result = await analyzeArtImage(base64);
      setAnalysis(result);
    } catch (err: any) {
      console.error("Analysis failed:", err);
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-16">
      <section className="text-center max-w-3xl mx-auto space-y-6 pt-8">
        <span className="text-xs font-bold text-indigo-600 uppercase tracking-[0.3em]">AI-Powered Vision</span>
        <h2 className="text-5xl md:text-7xl font-bold leading-tight">Every brushstroke has a story.</h2>
        <p className="text-xl text-slate-500 font-light leading-relaxed px-4">
          Upload an artwork and let ArtVision uncover its historical context, stylistic secrets, and hidden palettes.
        </p>
      </section>

      <div className="flex flex-col items-center gap-12">
        {!image ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full max-w-2xl h-80 border-2 border-dashed border-stone-300 rounded-[2.5rem] flex flex-col items-center justify-center gap-6 bg-white hover:border-indigo-400 hover:bg-indigo-50/30 transition-all cursor-pointer group shadow-sm"
          >
            <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 group-hover:shadow-md transition-all duration-300">
              <svg className="w-8 h-8 text-stone-400 group-hover:text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
            </div>
            <div className="text-center">
              <p className="text-xl font-medium text-slate-800">Select an artwork to begin</p>
              <p className="text-slate-400 mt-1">Supports JPG, PNG, and WebP formats</p>
            </div>
          </div>
        ) : (
          <div className="relative w-full max-w-2xl aspect-[4/3] rounded-[2.5rem] overflow-hidden shadow-2xl group border-8 border-white">
            <img src={image} alt="Target artwork" className="w-full h-full object-cover" />
            {loading && <div className="scanning-line"></div>}
            <button 
              onClick={() => {setImage(null); setAnalysis(null); setError(null);}}
              className="absolute top-6 right-6 bg-black/40 backdrop-blur-md p-3 rounded-full hover:bg-black/60 transition-colors text-white"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
          </div>
        )}

        <input 
          type="file" 
          accept="image/*" 
          className="hidden" 
          ref={fileInputRef} 
          onChange={handleImageUpload}
        />

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-900 px-8 py-6 rounded-[2rem] max-w-2xl w-full flex items-start gap-4 shadow-sm animate-in fade-in zoom-in-95">
            <svg className="w-6 h-6 text-red-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <div>
              <p className="font-bold text-lg">System Insight</p>
              <p className="text-red-700/80 leading-relaxed mt-1">{error}</p>
            </div>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3 text-indigo-600 font-semibold text-lg">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-600"></span>
              </span>
              Analyzing composition...
            </div>
          </div>
        )}

        {analysis && (
          <div className="w-full grid lg:grid-cols-12 gap-10 mt-4 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="lg:col-span-8 space-y-10">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                   <div className="h-px w-12 bg-indigo-600"></div>
                   <span className="text-sm font-bold text-indigo-600 uppercase tracking-[0.2em]">{analysis?.period}</span>
                </div>
                <h3 className="text-5xl font-bold leading-tight">{analysis?.title}</h3>
                <p className="text-2xl text-stone-400 font-serif italic">Created by {analysis?.artist}</p>
              </div>
              
              <div className="prose prose-lg text-slate-700 leading-relaxed max-w-none">
                <p className="text-xl leading-relaxed">{analysis?.description}</p>
              </div>

              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">Techniques Employed</h4>
                <div className="flex flex-wrap gap-3">
                  {analysis?.techniques?.map((tech, i) => (
                    <span key={i} className="px-5 py-2 bg-indigo-50 border border-indigo-100 rounded-2xl text-indigo-700 font-medium text-sm">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 bg-white p-8 rounded-[2rem] shadow-xl border border-stone-100 space-y-8 h-fit lg:sticky lg:top-24">
              <div className="flex justify-between items-center border-b border-stone-100 pb-4">
                <h4 className="font-bold text-xl">Extracted Palette</h4>
                <svg className="w-5 h-5 text-indigo-600" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4 2a2 2 0 00-2 2v11a3 3 0 106 0V4a2 2 0 00-2-2H4zm1 14a1 1 0 100-2 1 1 0 000 2zm5-1.757l4.9-4.9a2 2 0 000-2.828L13.485 5.1a2 2 0 00-2.828 0L10 5.757v8.486zM16 18H9.071l6-6H16a2 2 0 012 2v2a2 2 0 01-2 2z" clipRule="evenodd"></path></svg>
              </div>
              <div className="space-y-5">
                {analysis?.colorPalette?.map((color, i) => (
                  <div 
                    key={i} 
                    className="flex items-center gap-5 group cursor-pointer hover:translate-x-1 transition-transform"
                    onClick={() => navigator.clipboard.writeText(color)}
                  >
                    <div 
                      className="w-14 h-14 rounded-2xl shadow-sm ring-4 ring-white border border-stone-100"
                      style={{ backgroundColor: color }}
                    ></div>
                    <div className="flex flex-col">
                      <p className="text-sm font-mono font-bold text-slate-800 uppercase tracking-tighter">{color}</p>
                      <p className="text-[10px] text-slate-400 font-medium uppercase group-hover:text-indigo-500 transition-colors">Click to copy hex</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ArtAnalyzer;