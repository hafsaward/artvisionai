import { GoogleGenAI, Type } from "@google/genai";
import { ArtAnalysis, ArtIdea } from "../types";

// The API key is injected by Vite during the build process from vite.config.ts
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const extractJson = (text: string) => {
  try {
    // Attempt to find JSON block if the model wrapped it in markdown
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    const jsonStr = jsonMatch ? jsonMatch[0] : text;
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error("Failed to parse AI response as JSON", text);
    throw new Error("The gallery archives returned an unreadable format. Please try again.");
  }
};

export const analyzeArtImage = async (base64Image: string): Promise<ArtAnalysis> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: "Analyze this artwork. Provide the title, artist, period, a deep description, techniques used, and a list of 5 dominant hex color codes used in the work. Return in JSON format.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          artist: { type: Type.STRING },
          period: { type: Type.STRING },
          description: { type: Type.STRING },
          techniques: { type: Type.ARRAY, items: { type: Type.STRING } },
          colorPalette: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["title", "artist", "period", "description", "techniques", "colorPalette"],
      },
    },
  });

  return extractJson(response.text || '{}');
};

export const generateArtIdea = async (prompt: string): Promise<ArtIdea> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Give me a creative art project idea based on this theme: "${prompt}". Provide a title, the core concept, recommended materials, and the emotional vibe. Return in JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          concept: { type: Type.STRING },
          materials: { type: Type.ARRAY, items: { type: Type.STRING } },
          vibe: { type: Type.STRING },
        },
        required: ["title", "concept", "materials", "vibe"],
      },
    },
  });

  return extractJson(response.text || '{}');
};

export const chatWithArtHistorian = async (message: string, history: {role: string, parts: {text: string}[]}[]): Promise<string> => {
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are a world-renowned art historian and critic. You are insightful, eloquent, and passionate about art across all eras. Help the user understand art history, movements, and specific artists.",
    },
  });
  
  const response = await chat.sendMessage({ message });
  return response.text || "I apologize, I couldn't process that art inquiry.";
};